'use client';

import { useState, useCallback } from 'react';
import { FileText, Upload, BarChart3, Settings, Sparkles, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/hooks/use-toast';
import { InvoiceUpload } from '@/components/invoices/InvoiceUpload';
import { InvoiceList } from '@/components/invoices/InvoiceList';
import { InvoiceEditDialog } from '@/components/invoices/InvoiceEditDialog';
import { InvoiceViewDialog } from '@/components/invoices/InvoiceViewDialog';
import { ConfirmInvoiceDialog } from '@/components/invoices/ConfirmInvoiceDialog';
import type { Invoice, UploadResult, ExtractedInvoiceData } from '@/components/invoices/types';

export default function Home() {
  const { toast } = useToast();
  const [refreshKey, setRefreshKey] = useState(0);
  const [editInvoice, setEditInvoice] = useState<Invoice | null>(null);
  const [viewInvoice, setViewInvoice] = useState<Invoice | null>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  
  // Estado para el diálogo de confirmación
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);
  const [pendingInvoiceData, setPendingInvoiceData] = useState<{
    extractedData: ExtractedInvoiceData;
    fileName: string;
    importSource: 'pdf_import' | 'image_import';
  } | null>(null);

  const handleUploadComplete = useCallback((result: UploadResult) => {
    // Si los datos son buenos, mostrar diálogo de confirmación
    if (result.extractedData.confidence >= 30) {
      setPendingInvoiceData({
        extractedData: result.extractedData,
        fileName: result.originalName,
        importSource: result.importSource
      });
      setConfirmDialogOpen(true);
    }
    
    toast({
      title: 'OCR completado',
      description: `Se extrajo información con ${result.extractedData.confidence}% de confianza`,
      variant: result.extractedData.confidence >= 50 ? 'default' : 'destructive',
    });
  }, [toast]);

  const handleUploadError = useCallback((error: string) => {
    toast({
      title: 'Error al procesar',
      description: error,
      variant: 'destructive',
    });
  }, [toast]);

  const handleEditExtractedData = useCallback((data: ExtractedInvoiceData, fileName: string) => {
    // Abrir diálogo de confirmación con los datos
    setPendingInvoiceData({
      extractedData: data,
      fileName: fileName,
      importSource: 'pdf_import' // Default, el usuario puede cambiarlo
    });
    setConfirmDialogOpen(true);
  }, []);

  const handleConfirmInvoice = useCallback(() => {
    setConfirmDialogOpen(false);
    setPendingInvoiceData(null);
    setRefreshKey(k => k + 1);
    toast({
      title: 'Factura guardada',
      description: 'La factura se ha guardado correctamente',
    });
  }, [toast]);

  const handleEdit = useCallback((invoice: Invoice) => {
    setEditInvoice(invoice);
    setEditDialogOpen(true);
  }, []);

  const handleView = useCallback((invoice: Invoice) => {
    setViewInvoice(invoice);
    setViewDialogOpen(true);
  }, []);

  const handleSaveInvoice = useCallback((invoice: Invoice) => {
    setEditInvoice(null);
    setEditDialogOpen(false);
    setRefreshKey(k => k + 1);
    toast({
      title: 'Factura actualizada',
      description: `Los cambios se guardaron correctamente`,
    });
  }, [toast]);

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-background to-muted/30">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-lg">
                <FileText className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h1 className="text-xl font-bold">Invoice Importer</h1>
                <p className="text-sm text-muted-foreground">
                  Importación inteligente de facturas con OCR
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1 px-3 py-1 bg-primary/10 rounded-full text-xs text-primary font-medium">
                <Sparkles className="h-3 w-3" />
                Powered by VLM
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Panel de importación */}
          <div className="lg:col-span-1">
            <Card className="sticky top-24">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Upload className="h-5 w-5" />
                  Importar Factura
                </CardTitle>
                <CardDescription>
                  Sube PDFs o imágenes de facturas para extraer automáticamente los datos
                </CardDescription>
              </CardHeader>
              <CardContent>
                <InvoiceUpload 
                  onUploadComplete={handleUploadComplete}
                  onUploadError={handleUploadError}
                  onEditExtractedData={handleEditExtractedData}
                />
              </CardContent>
            </Card>
          </div>

          {/* Panel de lista de facturas */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="invoices" className="space-y-4">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="invoices">
                  <FileText className="h-4 w-4 mr-2" />
                  Facturas
                </TabsTrigger>
                <TabsTrigger value="stats">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Estadísticas
                </TabsTrigger>
                <TabsTrigger value="settings">
                  <Settings className="h-4 w-4 mr-2" />
                  Configuración
                </TabsTrigger>
              </TabsList>

              <TabsContent value="invoices">
                <InvoiceList 
                  onEdit={handleEdit}
                  onView={handleView}
                  refreshKey={refreshKey}
                />
              </TabsContent>

              <TabsContent value="stats">
                <Card>
                  <CardHeader>
                    <CardTitle>Estadísticas de Importación</CardTitle>
                    <CardDescription>
                      Resumen de las facturas procesadas
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-8 text-muted-foreground">
                      <BarChart3 className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>Las estadísticas aparecerán cuando tengas facturas importadas</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="settings">
                <Card>
                  <CardHeader>
                    <CardTitle>Configuración de OCR</CardTitle>
                    <CardDescription>
                      Ajusta los parámetros de procesamiento
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Alert>
                      <AlertCircle className="h-4 w-4" />
                      <AlertTitle>Procesamiento Inteligente</AlertTitle>
                      <AlertDescription>
                        El sistema utiliza un modelo de visión (VLM) para extraer datos de facturas 
                        de forma inteligente. Los formatos soportados son:
                        <ul className="mt-2 space-y-1 list-disc list-inside text-sm">
                          <li>Documentos PDF (conversión automática a imagen)</li>
                          <li>Imágenes JPG, PNG, WebP, GIF, BMP</li>
                          <li>Tickets y recibos en formato imagen</li>
                        </ul>
                      </AlertDescription>
                    </Alert>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t bg-background mt-auto">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <p>Invoice Importer - Procesamiento inteligente de facturas</p>
            <p>Utiliza VLM para OCR de alta precisión</p>
          </div>
        </div>
      </footer>

      {/* Dialogs */}
      <ConfirmInvoiceDialog
        open={confirmDialogOpen}
        onOpenChange={setConfirmDialogOpen}
        extractedData={pendingInvoiceData?.extractedData || null}
        fileName={pendingInvoiceData?.fileName || ''}
        importSource={pendingInvoiceData?.importSource || 'pdf_import'}
        onConfirm={handleConfirmInvoice}
      />

      <InvoiceEditDialog
        invoice={editInvoice}
        open={editDialogOpen}
        onOpenChange={setEditDialogOpen}
        onSave={handleSaveInvoice}
      />

      <InvoiceViewDialog
        invoice={viewInvoice}
        open={viewDialogOpen}
        onOpenChange={setViewDialogOpen}
        onEdit={handleEdit}
      />

      <Toaster />
    </div>
  );
}
