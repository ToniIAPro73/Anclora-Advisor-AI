import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { processInvoice, ExtractedInvoiceData } from '@/lib/invoice-processor/processor';
import fs from 'fs';
import path from 'path';

// Directorio de uploads
const UPLOAD_DIR = path.join(process.cwd(), 'uploads', 'invoices');

// Asegurar que el directorio existe
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

// Extensiones permitidas
const ALLOWED_EXTENSIONS = ['.pdf', '.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp'];
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB

// POST /api/invoices/upload - Subir y procesar una factura
export async function POST(request: NextRequest) {
  let filePath: string | null = null;
  
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File | null;
    const autoSave = formData.get('autoSave') === 'true';
    
    if (!file) {
      return NextResponse.json(
        { success: false, error: 'No se ha proporcionado ningún archivo' },
        { status: 400 }
      );
    }
    
    // Validar tamaño
    if (file.size > MAX_FILE_SIZE) {
      return NextResponse.json(
        { success: false, error: 'El archivo excede el tamaño máximo de 10MB' },
        { status: 400 }
      );
    }
    
    // Validar extensión
    const ext = path.extname(file.name).toLowerCase();
    if (!ALLOWED_EXTENSIONS.includes(ext)) {
      return NextResponse.json(
        { success: false, error: `Formato no soportado. Formatos permitidos: ${ALLOWED_EXTENSIONS.join(', ')}` },
        { status: 400 }
      );
    }
    
    // Generar nombre único
    const timestamp = Date.now();
    const randomSuffix = Math.random().toString(36).substring(2, 8);
    const fileName = `invoice_${timestamp}_${randomSuffix}${ext}`;
    filePath = path.join(UPLOAD_DIR, fileName);
    
    // Guardar archivo
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    fs.writeFileSync(filePath, buffer);
    
    // Determinar el tipo de importación
    const importSource = ext === '.pdf' ? 'pdf_import' : 'image_import';
    
    // Procesar la factura con VLM/OCR
    let extractedData: ExtractedInvoiceData;
    let processingError: string | null = null;
    
    try {
      extractedData = await processInvoice(filePath);
    } catch (processError) {
      console.error('Error processing invoice:', processError);
      processingError = processError instanceof Error ? processError.message : 'Error desconocido';
      
      // Si falla el procesamiento, devolver datos vacíos con el error
      extractedData = {
        clientName: '',
        clientNif: '',
        amountBase: 0,
        ivaRate: 21,
        irpfRetention: 0,
        totalAmount: 0,
        issueDate: new Date().toISOString().split('T')[0],
        confidence: 0,
        rawText: '',
        warnings: [`Error en el procesamiento OCR: ${processingError}`]
      };
    }
    
    // Guardar en la base de datos solo si autoSave está activado Y hay datos válidos
    let invoice = null;
    if (autoSave && extractedData.confidence >= 30) {
      try {
        // Asegurar que existe un usuario por defecto
        let defaultUser = await db.user.findUnique({
          where: { id: 'default-user' }
        });
        
        if (!defaultUser) {
          defaultUser = await db.user.create({
            data: {
              id: 'default-user',
              email: 'default@invoice-importer.local',
              name: 'Usuario por defecto'
            }
          });
        }
        
        invoice = await db.invoice.create({
          data: {
            userId: defaultUser.id,
            clientName: extractedData.clientName || 'Por completar',
            clientNif: extractedData.clientNif || 'Por completar',
            amountBase: extractedData.amountBase,
            ivaRate: extractedData.ivaRate,
            irpfRetention: extractedData.irpfRetention,
            totalAmount: extractedData.totalAmount,
            issueDate: new Date(extractedData.issueDate),
            status: 'draft',
            series: extractedData.series,
            invoiceNumber: extractedData.invoiceNumber ? parseInt(extractedData.invoiceNumber) : undefined,
            importSource,
            importFileName: file.name,
            importStoragePath: filePath,
            importConfidence: extractedData.confidence,
            importedAt: new Date(),
            ocrRawText: extractedData.rawText,
          }
        });
      } catch (dbError) {
        console.error('Error saving invoice:', dbError);
        // No fallar si hay error de BD, solo no guardar
      }
    }
    
    return NextResponse.json({
      success: true,
      data: {
        fileName,
        originalName: file.name,
        filePath,
        importSource,
        extractedData,
        invoice,
        processingError
      }
    });
  } catch (error) {
    console.error('Error in upload:', error);
    
    // Limpiar archivo si hubo error
    if (filePath && fs.existsSync(filePath)) {
      try {
        fs.unlinkSync(filePath);
      } catch {
        // Ignorar errores de limpieza
      }
    }
    
    return NextResponse.json(
      { success: false, error: `Error al procesar el archivo: ${error instanceof Error ? error.message : 'Error desconocido'}` },
      { status: 500 }
    );
  }
}
