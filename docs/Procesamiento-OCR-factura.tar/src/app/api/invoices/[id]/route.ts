import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/invoices/[id] - Obtener una factura específica
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    const invoice = await db.invoice.findUnique({
      where: { id },
      include: {
        payments: {
          orderBy: { paidAt: 'desc' }
        },
        rectifications: true,
        rectifiedBy: true
      }
    });
    
    if (!invoice) {
      return NextResponse.json(
        { success: false, error: 'Factura no encontrada' },
        { status: 404 }
      );
    }
    
    return NextResponse.json({
      success: true,
      data: invoice
    });
  } catch (error) {
    console.error('Error fetching invoice:', error);
    return NextResponse.json(
      { success: false, error: 'Error al obtener la factura' },
      { status: 500 }
    );
  }
}

// PUT /api/invoices/[id] - Actualizar una factura
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    
    // Verificar que la factura existe
    const existing = await db.invoice.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json(
        { success: false, error: 'Factura no encontrada' },
        { status: 404 }
      );
    }
    
    // Actualizar la factura
    const invoice = await db.invoice.update({
      where: { id },
      data: {
        clientName: body.clientName,
        clientNif: body.clientNif,
        amountBase: body.amountBase,
        ivaRate: body.ivaRate,
        irpfRetention: body.irpfRetention,
        totalAmount: body.totalAmount,
        issueDate: body.issueDate ? new Date(body.issueDate) : undefined,
        status: body.status,
        series: body.series,
        invoiceNumber: body.invoiceNumber,
        recipientEmail: body.recipientEmail,
        paymentMethod: body.paymentMethod,
        paymentReference: body.paymentReference,
        paymentNotes: body.paymentNotes,
        paidAt: body.paidAt ? new Date(body.paidAt) : undefined,
        invoiceType: body.invoiceType,
        rectificationReason: body.rectificationReason,
        ocrRawText: body.ocrRawText,
      }
    });
    
    return NextResponse.json({
      success: true,
      data: invoice
    });
  } catch (error) {
    console.error('Error updating invoice:', error);
    return NextResponse.json(
      { success: false, error: 'Error al actualizar la factura' },
      { status: 500 }
    );
  }
}

// DELETE /api/invoices/[id] - Eliminar una factura
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    // Verificar que la factura existe
    const existing = await db.invoice.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json(
        { success: false, error: 'Factura no encontrada' },
        { status: 404 }
      );
    }
    
    // Eliminar pagos asociados primero
    await db.invoicePayment.deleteMany({ where: { invoiceId: id } });
    
    // Eliminar la factura
    await db.invoice.delete({ where: { id } });
    
    return NextResponse.json({
      success: true,
      message: 'Factura eliminada correctamente'
    });
  } catch (error) {
    console.error('Error deleting invoice:', error);
    return NextResponse.json(
      { success: false, error: 'Error al eliminar la factura' },
      { status: 500 }
    );
  }
}
