import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/invoices - Listar todas las facturas
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const importSource = searchParams.get('importSource');
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');
    
    // Construir filtros
    const where: Record<string, unknown> = {};
    if (status) where.status = status;
    if (importSource) where.importSource = importSource;
    
    // Obtener facturas
    const invoices = await db.invoice.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: limit,
      skip: offset,
      include: {
        payments: {
          orderBy: { paidAt: 'desc' }
        }
      }
    });
    
    // Obtener total para paginación
    const total = await db.invoice.count({ where });
    
    return NextResponse.json({
      success: true,
      data: invoices,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total
      }
    });
  } catch (error) {
    console.error('Error fetching invoices:', error);
    return NextResponse.json(
      { success: false, error: 'Error al obtener las facturas' },
      { status: 500 }
    );
  }
}

// POST /api/invoices - Crear una nueva factura
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Validar datos requeridos
    if (!body.clientName || !body.clientNif) {
      return NextResponse.json(
        { success: false, error: 'Faltan campos requeridos: clientName, clientNif' },
        { status: 400 }
      );
    }
    
    // Asegurar que existe un usuario por defecto
    let defaultUser = await db.user.findUnique({
      where: { id: 'default-user' }
    });
    
    if (!defaultUser) {
      defaultUser = await db.user.create({
        data: {
          id: 'default-user',
          email: 'default@invoice-importer.local',
          name: 'Usuario por defecto'
        }
      });
    }
    
    // Crear la factura
    const invoice = await db.invoice.create({
      data: {
        userId: defaultUser.id,
        clientName: body.clientName,
        clientNif: body.clientNif,
        amountBase: body.amountBase || 0,
        ivaRate: body.ivaRate ?? 21,
        irpfRetention: body.irpfRetention ?? 0,
        totalAmount: body.totalAmount || 0,
        issueDate: body.issueDate ? new Date(body.issueDate) : new Date(),
        status: body.status || 'draft',
        series: body.series,
        invoiceNumber: body.invoiceNumber,
        recipientEmail: body.recipientEmail,
        importSource: body.importSource || 'manual',
        importFileName: body.importFileName,
        importStoragePath: body.importStoragePath,
        importConfidence: body.importConfidence,
        importedAt: body.importedAt ? new Date(body.importedAt) : undefined,
        ocrRawText: body.ocrRawText,
        invoiceType: body.invoiceType || 'standard',
      }
    });
    
    return NextResponse.json({
      success: true,
      data: invoice
    }, { status: 201 });
  } catch (error) {
    console.error('Error creating invoice:', error);
    return NextResponse.json(
      { success: false, error: 'Error al crear la factura' },
      { status: 500 }
    );
  }
}
