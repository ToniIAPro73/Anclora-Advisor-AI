import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

// Tipos para los datos extraídos de la factura
export interface ExtractedInvoiceData {
  clientName: string;
  clientNif: string;
  amountBase: number;
  ivaRate: number;
  irpfRetention: number;
  totalAmount: number;
  issueDate: string;
  invoiceNumber?: string;
  series?: string;
  confidence: number;
  rawText: string;
  warnings: string[];
}

// Prompt para extraer datos de facturas españolas
const EXTRACTION_PROMPT = `Eres un experto contable español especializado en extraer datos de facturas. Analiza esta imagen de factura y extrae la información en formato JSON.

INSTRUCCIONES CRÍTICAS:
1. Responde ÚNICAMENTE con un objeto JSON válido, sin explicaciones ni texto adicional
2. Si no puedes leer un campo, usa null
3. Sé muy preciso con los números (sin símbolos de moneda)

Campos a extraer:
{
  "clientName": "Nombre o razón social del EMISOR de la factura (quien emite la factura)",
  "clientNif": "NIF/CIF del emisor (letra + 8 números, sin espacios ni guiones)",
  "amountBase": "Base imponible ANTES de impuestos (número decimal)",
  "ivaRate": "Porcentaje de IVA aplicado (normalmente 21, 10 o 4)",
  "irpfRetention": "Porcentaje de retención IRPF si aplica (normalmente 15 o 7, si no hay pon 0)",
  "totalAmount": "Importe TOTAL a pagar de la factura (número decimal)",
  "issueDate": "Fecha de emisión en formato YYYY-MM-DD",
  "invoiceNumber": "Número de factura si aparece",
  "series": "Serie de la factura si aparece (ej: A, B, 2024)",
  "confidence": "Tu nivel de confianza global en la extracción (0-100)"
}

EJEMPLO DE RESPUESTA:
{"clientName":"Empresa Ejemplo SL","clientNif":"B12345678","amountBase":1000.00,"ivaRate":21,"irpfRetention":0,"totalAmount":1210.00,"issueDate":"2024-03-15","invoiceNumber":"001","series":"A","confidence":95}

Analiza ahora la imagen:`;

/**
 * Convierte un PDF a imagen usando ImageMagick (más confiable)
 */
function convertPdfToImageSync(pdfPath: string): string {
  const outputPath = pdfPath.replace('.pdf', '.png');
  
  try {
    // Usar convert de ImageMagick directamente
    execSync(`convert -density 200 -quality 90 "${pdfPath}[0]" "${outputPath}"`, {
      timeout: 30000,
      stdio: 'pipe'
    });
    
    if (fs.existsSync(outputPath)) {
      return outputPath;
    }
    throw new Error('No se generó la imagen de salida');
  } catch (error) {
    console.error('Error converting PDF with ImageMagick:', error);
    
    // Intentar con pdftoppm si existe
    try {
      const pdftoppmOutput = pdfPath.replace('.pdf', '');
      execSync(`pdftoppm -png -r 200 "${pdfPath}" "${pdftoppmOutput}"`, {
        timeout: 30000,
        stdio: 'pipe'
      });
      
      // pdftoppm genera archivos con sufijo -1.png
      const generatedFile = `${pdftoppmOutput}-1.png`;
      if (fs.existsSync(generatedFile)) {
        // Renombrar al formato esperado
        fs.renameSync(generatedFile, outputPath);
        return outputPath;
      }
    } catch (pdftoppmError) {
      console.error('Error with pdftoppm:', pdftoppmError);
    }
    
    throw new Error(`Error al convertir PDF a imagen: ${error instanceof Error ? error.message : 'Error desconocido'}`);
  }
}

/**
 * Procesa una imagen de factura usando VLM con reintentos
 */
export async function processInvoiceImage(imagePath: string, retries = 2): Promise<ExtractedInvoiceData> {
  const zai = await ZAI.create();
  
  // Leer la imagen y convertirla a base64
  const imageBuffer = fs.readFileSync(imagePath);
  const base64Image = imageBuffer.toString('base64');
  
  // Determinar el tipo MIME
  const ext = path.extname(imagePath).toLowerCase();
  const mimeType = ext === '.png' ? 'image/png' : 
                   ext === '.gif' ? 'image/gif' :
                   ext === '.webp' ? 'image/webp' : 'image/jpeg';
  
  const imageUrl = `data:${mimeType};base64,${base64Image}`;
  
  let lastError: Error | null = null;
  
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      if (attempt > 0) {
        console.log(`Retry attempt ${attempt} for image processing...`);
        // Esperar un poco antes de reintentar
        await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
      }
      
      const response = await zai.chat.completions.createVision({
        messages: [
          {
            role: 'user',
            content: [
              { type: 'text', text: EXTRACTION_PROMPT },
              { type: 'image_url', image_url: { url: imageUrl } }
            ]
          }
        ],
        thinking: { type: 'disabled' }
      });
      
      const content = response.choices[0]?.message?.content || '';
      return parseExtractionResponse(content);
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      console.error(`Error processing invoice image (attempt ${attempt}):`, error);
      
      // Si es un error de la API (5xx), reintentar
      if (error instanceof Error && error.message.includes('500')) {
        continue;
      }
      // Si es otro tipo de error, no reintentar
      break;
    }
  }
  
  throw new Error(`Error al procesar la imagen después de ${retries + 1} intentos: ${lastError?.message || 'Error desconocido'}`);
}

/**
 * Procesa un PDF de factura convirtiéndolo primero a imagen
 */
export async function processInvoicePdf(pdfPath: string): Promise<ExtractedInvoiceData> {
  let imagePath: string | null = null;
  
  try {
    // Convertir PDF a imagen
    imagePath = convertPdfToImageSync(pdfPath);
    console.log(`PDF converted to image: ${imagePath}`);
    
    // Procesar la imagen resultante
    const result = await processInvoiceImage(imagePath);
    
    return result;
  } catch (error) {
    console.error('Error processing PDF:', error);
    throw new Error(`Error al procesar el PDF: ${error instanceof Error ? error.message : 'Error desconocido'}`);
  } finally {
    // Limpiar imagen temporal si se creó
    if (imagePath && fs.existsSync(imagePath)) {
      try {
        fs.unlinkSync(imagePath);
      } catch {
        // Ignorar errores de limpieza
      }
    }
  }
}

/**
 * Procesa una factura (imagen o PDF)
 */
export async function processInvoice(filePath: string): Promise<ExtractedInvoiceData> {
  const ext = path.extname(filePath).toLowerCase();
  
  // Validar que el archivo existe
  if (!fs.existsSync(filePath)) {
    throw new Error(`El archivo no existe: ${filePath}`);
  }
  
  // Procesar según el tipo de archivo
  if (ext === '.pdf') {
    return processInvoicePdf(filePath);
  } else if (['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp'].includes(ext)) {
    return processInvoiceImage(filePath);
  } else {
    throw new Error(`Formato de archivo no soportado: ${ext}`);
  }
}

/**
 * Parsea la respuesta del VLM y la estructura como ExtractedInvoiceData
 */
function parseExtractionResponse(content: string): ExtractedInvoiceData {
  const warnings: string[] = [];
  
  try {
    // Limpiar la respuesta de posibles caracteres extra
    let cleanContent = content.trim();
    
    // Si la respuesta está envuelta en markdown, extraer el JSON
    const jsonMatch = cleanContent.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (jsonMatch) {
      cleanContent = jsonMatch[1].trim();
    }
    
    // Buscar el objeto JSON en el contenido
    const jsonObjectMatch = cleanContent.match(/\{[\s\S]*\}/);
    if (jsonObjectMatch) {
      cleanContent = jsonObjectMatch[0];
    }
    
    // Intentar parsear el JSON
    const parsed = JSON.parse(cleanContent);
    
    // Verificar si hay error
    if (parsed.error) {
      throw new Error(parsed.error);
    }
    
    // Validar y normalizar los datos
    const result: ExtractedInvoiceData = {
      clientName: parsed.clientName || '',
      clientNif: normalizeNif(parsed.clientNif) || '',
      amountBase: parseNumber(parsed.amountBase) || 0,
      ivaRate: parseNumber(parsed.ivaRate) ?? 21,
      irpfRetention: parseNumber(parsed.irpfRetention) ?? 0,
      totalAmount: parseNumber(parsed.totalAmount) || 0,
      issueDate: parseDate(parsed.issueDate) || new Date().toISOString().split('T')[0],
      invoiceNumber: parsed.invoiceNumber || undefined,
      series: parsed.series || undefined,
      confidence: Math.min(100, Math.max(0, parsed.confidence || 50)),
      rawText: content,
      warnings
    };
    
    // Añadir advertencias si hay datos faltantes
    if (!result.clientName) warnings.push('No se pudo extraer el nombre del cliente');
    if (!result.clientNif) warnings.push('No se pudo extraer el NIF/CIF');
    if (!result.amountBase) warnings.push('No se pudo extraer la base imponible');
    if (!result.totalAmount) warnings.push('No se pudo extraer el importe total');
    
    // Verificar coherencia de totales
    if (result.amountBase > 0 && result.totalAmount > 0) {
      const calculatedTotal = result.amountBase * (1 + result.ivaRate / 100) * (1 - result.irpfRetention / 100);
      if (Math.abs(calculatedTotal - result.totalAmount) > 0.5) {
        warnings.push(`El total calculado (${calculatedTotal.toFixed(2)}€) no coincide con el extraído (${result.totalAmount.toFixed(2)}€)`);
      }
    }
    
    return result;
  } catch (parseError) {
    console.error('Error parsing VLM response:', parseError, 'Content:', content);
    
    // Devolver datos vacíos con baja confianza
    return {
      clientName: '',
      clientNif: '',
      amountBase: 0,
      ivaRate: 21,
      irpfRetention: 0,
      totalAmount: 0,
      issueDate: new Date().toISOString().split('T')[0],
      confidence: 0,
      rawText: content,
      warnings: ['Error al interpretar la respuesta del modelo de visión. Por favor, introduce los datos manualmente.']
    };
  }
}

/**
 * Normaliza un NIF/CIF
 */
function normalizeNif(nif: string | null | undefined): string {
  if (!nif) return '';
  
  // Eliminar espacios y guiones
  let normalized = nif.toUpperCase().replace(/[\s\-\.]/g, '');
  
  // Si tiene el formato correcto (letra + 8 dígitos + letra opcional)
  if (/^[A-Z]\d{8}[A-Z]?$/.test(normalized)) {
    return normalized;
  }
  
  // Si tiene 8 dígitos, es un NIF numérico
  if (/^\d{8}[A-Z]?$/.test(normalized)) {
    return normalized;
  }
  
  // Si tiene 9 caracteres empezando por letra
  if (/^[A-Z]\d{8}$/.test(normalized)) {
    return normalized;
  }
  
  return normalized;
}

/**
 * Parsea un número de forma segura
 */
function parseNumber(value: unknown): number | null {
  if (value === null || value === undefined) return null;
  if (typeof value === 'number') return value;
  if (typeof value === 'string') {
    // Eliminar símbolos de euro, espacios, puntos de miles y cambiar coma por punto
    const clean = value
      .replace(/[€\s]/g, '')
      .replace(/\./g, '') // Eliminar puntos de miles
      .replace(',', '.'); // Cambiar coma decimal por punto
    
    const parsed = parseFloat(clean);
    return isNaN(parsed) ? null : parsed;
  }
  return null;
}

/**
 * Parsea una fecha de forma segura
 */
function parseDate(value: unknown): string | null {
  if (!value) return null;
  
  const dateStr = String(value);
  
  // Intentar varios formatos
  const formats = [
    /^(\d{4})-(\d{2})-(\d{2})$/,           // YYYY-MM-DD
    /^(\d{2})\/(\d{2})\/(\d{4})$/,         // DD/MM/YYYY
    /^(\d{2})-(\d{2})-(\d{4})$/,           // DD-MM-YYYY
    /^(\d{4})\/(\d{2})\/(\d{2})$/,         // YYYY/MM/DD
  ];
  
  for (const format of formats) {
    const match = dateStr.match(format);
    if (match) {
      if (format === formats[0] || format === formats[3]) {
        return `${match[1]}-${match[2]}-${match[3]}`;
      } else {
        // DD/MM/YYYY -> YYYY-MM-DD
        return `${match[3]}-${match[2]}-${match[1]}`;
      }
    }
  }
  
  // Intentar parsear directamente
  const date = new Date(dateStr);
  if (!isNaN(date.getTime())) {
    return date.toISOString().split('T')[0];
  }
  
  return null;
}
