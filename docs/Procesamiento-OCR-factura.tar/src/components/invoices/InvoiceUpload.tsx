'use client';

import { useState, useCallback } from 'react';
import { Upload, FileText, Image, X, AlertCircle, CheckCircle, Loader2, Edit } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import type { UploadResult, ExtractedInvoiceData } from './types';

interface InvoiceUploadProps {
  onUploadComplete: (result: UploadResult) => void;
  onUploadError: (error: string) => void;
  onEditExtractedData?: (data: ExtractedInvoiceData, fileName: string) => void;
}

export function InvoiceUpload({ onUploadComplete, onUploadError, onEditExtractedData }: InvoiceUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadStatus, setUploadStatus] = useState<string>('');
  const [previewFile, setPreviewFile] = useState<File | null>(null);
  const [lastResult, setLastResult] = useState<UploadResult | null>(null);
  const [processingError, setProcessingError] = useState<string | null>(null);

  const allowedTypes = [
    'application/pdf',
    'image/jpeg',
    'image/jpg',
    'image/png',
    'image/gif',
    'image/webp',
    'image/bmp'
  ];

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFile(files[0]);
    }
  }, []);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFile(files[0]);
    }
  }, []);

  const handleFile = async (file: File) => {
    // Validar tipo
    if (!allowedTypes.includes(file.type)) {
      onUploadError(`Tipo de archivo no soportado: ${file.type}. Use PDF o imágenes.`);
      return;
    }

    // Validar tamaño (10MB)
    if (file.size > 10 * 1024 * 1024) {
      onUploadError('El archivo excede el tamaño máximo de 10MB.');
      return;
    }

    setPreviewFile(file);
    setLastResult(null);
    setProcessingError(null);
  };

  const uploadFile = async () => {
    if (!previewFile) return;

    setIsUploading(true);
    setUploadProgress(0);
    setUploadStatus('Preparando archivo...');
    setProcessingError(null);

    const formData = new FormData();
    formData.append('file', previewFile);
    formData.append('autoSave', 'false'); // No guardar automáticamente

    try {
      setUploadProgress(20);
      setUploadStatus('Subiendo archivo...');

      const response = await fetch('/api/invoices/upload', {
        method: 'POST',
        body: formData
      });

      setUploadProgress(50);
      setUploadStatus('Procesando con OCR...');

      const result = await response.json();

      setUploadProgress(90);

      if (!result.success) {
        throw new Error(result.error || 'Error al procesar el archivo');
      }

      setUploadProgress(100);
      setUploadStatus('¡Completado!');
      setLastResult(result.data);
      
      // Si los datos extraídos son buenos, notificar
      if (result.data.extractedData.confidence >= 30) {
        onUploadComplete(result.data);
      } else {
        // Datos de baja calidad, mostrar error pero permitir editar
        setProcessingError('El OCR no pudo extraer datos confiables. Por favor, introduce los datos manualmente.');
      }

      // Reset después de un momento
      setTimeout(() => {
        setIsUploading(false);
        setUploadProgress(0);
        setUploadStatus('');
      }, 1500);

    } catch (error) {
      console.error('Upload error:', error);
      const errorMsg = error instanceof Error ? error.message : 'Error desconocido';
      setProcessingError(errorMsg);
      onUploadError(errorMsg);
      setIsUploading(false);
      setUploadProgress(0);
      setUploadStatus('');
    }
  };

  const cancelUpload = () => {
    setPreviewFile(null);
    setLastResult(null);
    setProcessingError(null);
    setUploadProgress(0);
    setUploadStatus('');
  };

  const handleManualEdit = () => {
    if (lastResult && onEditExtractedData) {
      onEditExtractedData(lastResult.extractedData, lastResult.originalName);
    }
  };

  const getFileIcon = (type: string) => {
    if (type === 'application/pdf') return <FileText className="h-12 w-12 text-red-500" />;
    return <Image className="h-12 w-12 text-blue-500" />;
  };

  return (
    <div className="space-y-4">
      {/* Zona de drop */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`
          relative border-2 border-dashed rounded-xl p-8 text-center transition-all duration-200
          ${isDragging 
            ? 'border-primary bg-primary/5 scale-[1.02]' 
            : 'border-muted-foreground/25 hover:border-primary/50 hover:bg-muted/30'
          }
          ${isUploading ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
        `}
      >
        <input
          type="file"
          accept=".pdf,.jpg,.jpeg,.png,.gif,.webp,.bmp"
          onChange={handleFileSelect}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          disabled={isUploading}
        />
        
        <div className="flex flex-col items-center gap-3">
          <div className={`
            p-4 rounded-full transition-colors
            ${isDragging ? 'bg-primary/10' : 'bg-muted'}
          `}>
            <Upload className={`h-8 w-8 ${isDragging ? 'text-primary' : 'text-muted-foreground'}`} />
          </div>
          
          <div>
            <p className="text-lg font-medium">
              {isDragging ? 'Suelta el archivo aquí' : 'Arrastra y suelta tu factura'}
            </p>
            <p className="text-sm text-muted-foreground mt-1">
              o haz clic para seleccionar
            </p>
          </div>
          
          <div className="flex gap-2 flex-wrap justify-center mt-2">
            <Badge variant="outline" className="text-xs">PDF</Badge>
            <Badge variant="outline" className="text-xs">JPG</Badge>
            <Badge variant="outline" className="text-xs">PNG</Badge>
            <Badge variant="outline" className="text-xs">WebP</Badge>
          </div>
          
          <p className="text-xs text-muted-foreground">
            Máximo 10MB
          </p>
        </div>
      </div>

      {/* Vista previa del archivo */}
      {previewFile && !isUploading && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0">
                {getFileIcon(previewFile.type)}
              </div>
              
              <div className="flex-1 min-w-0">
                <p className="font-medium truncate">{previewFile.name}</p>
                <p className="text-sm text-muted-foreground">
                  {(previewFile.size / 1024).toFixed(1)} KB
                </p>
              </div>
              
              <div className="flex gap-2">
                <Button onClick={uploadFile} size="sm">
                  Procesar
                </Button>
                <Button onClick={cancelUpload} size="sm" variant="ghost">
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Barra de progreso */}
      {isUploading && (
        <Card>
          <CardContent className="p-4">
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <Loader2 className="h-5 w-5 animate-spin text-primary" />
                <span className="text-sm font-medium">{uploadStatus}</span>
              </div>
              <Progress value={uploadProgress} className="h-2" />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Error de procesamiento */}
      {processingError && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="flex-1">
            <p className="font-medium">Error en el procesamiento OCR</p>
            <p className="text-sm mt-1">{processingError}</p>
            {lastResult && (
              <Button 
                variant="outline" 
                size="sm" 
                className="mt-2"
                onClick={handleManualEdit}
              >
                <Edit className="h-4 w-4 mr-2" />
                Introducir datos manualmente
              </Button>
            )}
          </AlertDescription>
        </Alert>
      )}

      {/* Resultado del procesamiento */}
      {lastResult && lastResult.extractedData.confidence >= 30 && (
        <Card className="border-green-200 bg-green-50/50">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-medium text-green-800">Factura procesada correctamente</p>
                <div className="mt-2 space-y-1 text-sm text-green-700">
                  <p><strong>Cliente:</strong> {lastResult.extractedData.clientName || 'No detectado'}</p>
                  <p><strong>NIF:</strong> {lastResult.extractedData.clientNif || 'No detectado'}</p>
                  <p><strong>Total:</strong> €{lastResult.extractedData.totalAmount.toFixed(2)}</p>
                  <p><strong>Confianza:</strong> {lastResult.extractedData.confidence}%</p>
                </div>
                
                {lastResult.extractedData.warnings.length > 0 && (
                  <div className="mt-3 space-y-1">
                    {lastResult.extractedData.warnings.map((warning, i) => (
                      <p key={i} className="text-xs text-amber-600 flex items-center gap-1">
                        <AlertCircle className="h-3 w-3" />
                        {warning}
                      </p>
                    ))}
                  </div>
                )}
                
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="mt-3"
                  onClick={handleManualEdit}
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Editar datos extraídos
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
