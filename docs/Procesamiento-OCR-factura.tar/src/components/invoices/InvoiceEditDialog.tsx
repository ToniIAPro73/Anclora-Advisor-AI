'use client';

import { useState, useEffect } from 'react';
import { X, Save, AlertCircle, Loader2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import type { Invoice } from './types';

interface InvoiceEditDialogProps {
  invoice: Invoice | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (invoice: Invoice) => void;
}

export function InvoiceEditDialog({ invoice, open, onOpenChange, onSave }: InvoiceEditDialogProps) {
  const [formData, setFormData] = useState<Partial<Invoice>>({});
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (invoice) {
      setFormData({
        clientName: invoice.clientName,
        clientNif: invoice.clientNif,
        amountBase: invoice.amountBase,
        ivaRate: invoice.ivaRate,
        irpfRetention: invoice.irpfRetention,
        totalAmount: invoice.totalAmount,
        issueDate: invoice.issueDate.split('T')[0],
        status: invoice.status,
        series: invoice.series,
        invoiceNumber: invoice.invoiceNumber,
        recipientEmail: invoice.recipientEmail,
        paymentNotes: invoice.paymentNotes,
      });
    }
  }, [invoice]);

  const handleChange = (field: keyof Invoice, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setError(null);
  };

  const calculateTotal = () => {
    const base = Number(formData.amountBase) || 0;
    const iva = Number(formData.ivaRate) || 0;
    const irpf = Number(formData.irpfRetention) || 0;
    
    const total = base * (1 + iva / 100) * (1 - irpf / 100);
    return Math.round(total * 100) / 100;
  };

  const handleSave = async () => {
    if (!invoice) return;

    // Validación básica
    if (!formData.clientName || !formData.clientNif) {
      setError('El nombre del cliente y NIF son obligatorios');
      return;
    }

    setSaving(true);
    setError(null);

    try {
      const totalAmount = calculateTotal();
      
      const response = await fetch(`/api/invoices/${invoice.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          totalAmount
        })
      });

      const result = await response.json();

      if (!result.success) {
        throw new Error(result.error || 'Error al guardar');
      }

      onSave(result.data);
      onOpenChange(false);
    } catch (err) {
      console.error('Error saving invoice:', err);
      setError(err instanceof Error ? err.message : 'Error al guardar');
    } finally {
      setSaving(false);
    }
  };

  if (!invoice) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            Editar Factura
            {invoice.importSource !== 'manual' && (
              <Badge variant="outline" className="text-xs">
                Importada de {invoice.importSource === 'pdf_import' ? 'PDF' : 'Imagen'}
              </Badge>
            )}
          </DialogTitle>
          <DialogDescription>
            Revisa y corrige los datos extraídos de la factura
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Datos del cliente */}
          <div className="space-y-4">
            <h4 className="text-sm font-medium text-muted-foreground">Datos del Cliente</h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="clientName">Nombre / Razón Social *</Label>
                <Input
                  id="clientName"
                  value={formData.clientName || ''}
                  onChange={(e) => handleChange('clientName', e.target.value)}
                  placeholder="Nombre del cliente"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="clientNif">NIF / CIF *</Label>
                <Input
                  id="clientNif"
                  value={formData.clientNif || ''}
                  onChange={(e) => handleChange('clientNif', e.target.value.toUpperCase())}
                  placeholder="B12345678"
                  className="uppercase"
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Datos financieros */}
          <div className="space-y-4">
            <h4 className="text-sm font-medium text-muted-foreground">Datos Financieros</h4>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="amountBase">Base Imponible (€)</Label>
                <Input
                  id="amountBase"
                  type="number"
                  step="0.01"
                  value={formData.amountBase || ''}
                  onChange={(e) => handleChange('amountBase', parseFloat(e.target.value) || 0)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="ivaRate">IVA (%)</Label>
                <Select
                  value={String(formData.ivaRate || 21)}
                  onValueChange={(v) => handleChange('ivaRate', parseFloat(v))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="21">21%</SelectItem>
                    <SelectItem value="10">10%</SelectItem>
                    <SelectItem value="4">4%</SelectItem>
                    <SelectItem value="0">0%</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="irpfRetention">IRPF (%)</Label>
                <Select
                  value={String(formData.irpfRetention || 0)}
                  onValueChange={(v) => handleChange('irpfRetention', parseFloat(v))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">0%</SelectItem>
                    <SelectItem value="7">7%</SelectItem>
                    <SelectItem value="15">15%</SelectItem>
                    <SelectItem value="19">19%</SelectItem>
                    <SelectItem value="20">20%</SelectItem>
                    <SelectItem value="21">21%</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
              <span className="text-sm font-medium">Total Calculado:</span>
              <span className="text-lg font-bold text-primary">
                €{calculateTotal().toFixed(2)}
              </span>
            </div>
          </div>

          <Separator />

          {/* Datos adicionales */}
          <div className="space-y-4">
            <h4 className="text-sm font-medium text-muted-foreground">Datos Adicionales</h4>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="issueDate">Fecha de Emisión</Label>
                <Input
                  id="issueDate"
                  type="date"
                  value={formData.issueDate || ''}
                  onChange={(e) => handleChange('issueDate', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="series">Serie</Label>
                <Input
                  id="series"
                  value={formData.series || ''}
                  onChange={(e) => handleChange('series', e.target.value)}
                  placeholder="A"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="invoiceNumber">Número</Label>
                <Input
                  id="invoiceNumber"
                  type="number"
                  value={formData.invoiceNumber || ''}
                  onChange={(e) => handleChange('invoiceNumber', parseInt(e.target.value) || undefined)}
                  placeholder="001"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="status">Estado</Label>
                <Select
                  value={formData.status || 'draft'}
                  onValueChange={(v) => handleChange('status', v)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Borrador</SelectItem>
                    <SelectItem value="issued">Emitida</SelectItem>
                    <SelectItem value="paid">Pagada</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="recipientEmail">Email Destinatario</Label>
                <Input
                  id="recipientEmail"
                  type="email"
                  value={formData.recipientEmail || ''}
                  onChange={(e) => handleChange('recipientEmail', e.target.value)}
                  placeholder="cliente@email.com"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="paymentNotes">Notas</Label>
              <Textarea
                id="paymentNotes"
                value={formData.paymentNotes || ''}
                onChange={(e) => handleChange('paymentNotes', e.target.value)}
                placeholder="Notas adicionales..."
                rows={2}
              />
            </div>
          </div>

          {/* Información de importación */}
          {invoice.importSource !== 'manual' && (
            <>
              <Separator />
              <div className="space-y-2">
                <h4 className="text-sm font-medium text-muted-foreground">Información de Importación</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Archivo original:</span>
                    <p className="font-medium">{invoice.importFileName}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Confianza OCR:</span>
                    <p className="font-medium">{invoice.importConfidence}%</p>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={saving}>
            {saving ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Guardando...
              </>
            ) : (
              <>
                <Save className="h-4 w-4 mr-2" />
                Guardar Cambios
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
