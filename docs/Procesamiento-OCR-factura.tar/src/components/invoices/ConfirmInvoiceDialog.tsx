'use client';

import { useState, useEffect } from 'react';
import { Save, AlertCircle, Loader2, FileText, Image } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import type { ExtractedInvoiceData } from './types';

interface ConfirmInvoiceDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  extractedData: ExtractedInvoiceData | null;
  fileName: string;
  importSource: 'pdf_import' | 'image_import';
  onConfirm: (data: Partial<ExtractedInvoiceData>) => void;
}

export function ConfirmInvoiceDialog({
  open,
  onOpenChange,
  extractedData,
  fileName,
  importSource,
  onConfirm
}: ConfirmInvoiceDialogProps) {
  const [formData, setFormData] = useState<Partial<ExtractedInvoiceData>>({});
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (extractedData) {
      setFormData({
        clientName: extractedData.clientName || '',
        clientNif: extractedData.clientNif || '',
        amountBase: extractedData.amountBase || 0,
        ivaRate: extractedData.ivaRate || 21,
        irpfRetention: extractedData.irpfRetention || 0,
        totalAmount: extractedData.totalAmount || 0,
        issueDate: extractedData.issueDate || new Date().toISOString().split('T')[0],
        invoiceNumber: extractedData.invoiceNumber || '',
        series: extractedData.series || '',
      });
    }
  }, [extractedData]);

  const handleChange = (field: keyof ExtractedInvoiceData, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setError(null);
  };

  const calculateTotal = () => {
    const base = Number(formData.amountBase) || 0;
    const iva = Number(formData.ivaRate) || 0;
    const irpf = Number(formData.irpfRetention) || 0;
    
    const total = base * (1 + iva / 100) * (1 - irpf / 100);
    return Math.round(total * 100) / 100;
  };

  const handleConfirm = async () => {
    // Validación básica
    if (!formData.clientName || !formData.clientNif) {
      setError('El nombre del cliente y NIF son obligatorios');
      return;
    }

    setSaving(true);
    setError(null);

    try {
      const totalAmount = calculateTotal();
      
      // Crear la factura en la base de datos
      const response = await fetch('/api/invoices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          totalAmount,
          importSource,
          importFileName: fileName,
          importConfidence: extractedData?.confidence || 0,
          ocrRawText: extractedData?.rawText || '',
        })
      });

      const result = await response.json();

      if (!result.success) {
        throw new Error(result.error || 'Error al guardar');
      }

      onConfirm(formData);
      onOpenChange(false);
    } catch (err) {
      console.error('Error saving invoice:', err);
      setError(err instanceof Error ? err.message : 'Error al guardar');
    } finally {
      setSaving(false);
    }
  };

  if (!extractedData) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {importSource === 'pdf_import' ? (
              <FileText className="h-5 w-5 text-red-500" />
            ) : (
              <Image className="h-5 w-5 text-blue-500" />
            )}
            Confirmar Datos de Factura
          </DialogTitle>
          <DialogDescription>
            Revisa y corrige los datos extraídos antes de guardar
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Info del archivo */}
          <div className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg">
            <span className="text-sm text-muted-foreground">Archivo:</span>
            <span className="text-sm font-medium">{fileName}</span>
            <Badge variant="outline" className="ml-auto">
              {extractedData.confidence}% confianza
            </Badge>
          </div>

          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Datos del cliente */}
          <div className="space-y-3">
            <h4 className="text-sm font-medium text-muted-foreground">Datos del Cliente</h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="clientName">Nombre / Razón Social *</Label>
                <Input
                  id="clientName"
                  value={formData.clientName || ''}
                  onChange={(e) => handleChange('clientName', e.target.value)}
                  placeholder="Nombre del cliente"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="clientNif">NIF / CIF *</Label>
                <Input
                  id="clientNif"
                  value={formData.clientNif || ''}
                  onChange={(e) => handleChange('clientNif', e.target.value.toUpperCase())}
                  placeholder="B12345678"
                  className="uppercase"
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Datos financieros */}
          <div className="space-y-3">
            <h4 className="text-sm font-medium text-muted-foreground">Datos Financieros</h4>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="amountBase">Base Imponible (€)</Label>
                <Input
                  id="amountBase"
                  type="number"
                  step="0.01"
                  value={formData.amountBase || ''}
                  onChange={(e) => handleChange('amountBase', parseFloat(e.target.value) || 0)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="ivaRate">IVA (%)</Label>
                <Select
                  value={String(formData.ivaRate || 21)}
                  onValueChange={(v) => handleChange('ivaRate', parseFloat(v))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="21">21%</SelectItem>
                    <SelectItem value="10">10%</SelectItem>
                    <SelectItem value="4">4%</SelectItem>
                    <SelectItem value="0">0%</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="irpfRetention">IRPF (%)</Label>
                <Select
                  value={String(formData.irpfRetention || 0)}
                  onValueChange={(v) => handleChange('irpfRetention', parseFloat(v))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">0%</SelectItem>
                    <SelectItem value="7">7%</SelectItem>
                    <SelectItem value="15">15%</SelectItem>
                    <SelectItem value="19">19%</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-primary/10 rounded-lg border border-primary/20">
              <span className="text-sm font-medium">Total Calculado:</span>
              <span className="text-xl font-bold text-primary">
                €{calculateTotal().toFixed(2)}
              </span>
            </div>
          </div>

          <Separator />

          {/* Datos adicionales */}
          <div className="space-y-3">
            <h4 className="text-sm font-medium text-muted-foreground">Datos Adicionales</h4>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="issueDate">Fecha de Emisión</Label>
                <Input
                  id="issueDate"
                  type="date"
                  value={formData.issueDate || ''}
                  onChange={(e) => handleChange('issueDate', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="series">Serie</Label>
                <Input
                  id="series"
                  value={formData.series || ''}
                  onChange={(e) => handleChange('series', e.target.value)}
                  placeholder="A"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="invoiceNumber">Número</Label>
                <Input
                  id="invoiceNumber"
                  value={formData.invoiceNumber || ''}
                  onChange={(e) => handleChange('invoiceNumber', e.target.value)}
                  placeholder="001"
                />
              </div>
            </div>
          </div>

          {/* Warnings */}
          {extractedData.warnings.length > 0 && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                <p className="font-medium mb-1">Advertencias del OCR:</p>
                <ul className="text-sm space-y-1">
                  {extractedData.warnings.map((warning, i) => (
                    <li key={i}>• {warning}</li>
                  ))}
                </ul>
              </AlertDescription>
            </Alert>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleConfirm} disabled={saving}>
            {saving ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Guardando...
              </>
            ) : (
              <>
                <Save className="h-4 w-4 mr-2" />
                Guardar Factura
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
