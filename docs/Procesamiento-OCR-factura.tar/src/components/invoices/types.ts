// Tipos para las facturas
export interface Invoice {
  id: string;
  userId: string;
  clientName: string;
  clientNif: string;
  amountBase: number;
  ivaRate: number;
  irpfRetention: number;
  totalAmount: number;
  issueDate: string;
  status: 'draft' | 'issued' | 'paid';
  series?: string;
  invoiceNumber?: number;
  recipientEmail?: string;
  sentAt?: string;
  paidAt?: string;
  paymentMethod?: string;
  paymentReference?: string;
  paymentNotes?: string;
  invoiceType: 'standard' | 'rectificative';
  rectifiesInvoiceId?: string;
  rectificationReason?: string;
  verifactuStatus: 'not_sent' | 'queued' | 'submitted' | 'failed';
  verifactuSubmittedAt?: string;
  verifactuSubmissionId?: string;
  verifactuLastError?: string;
  importSource: 'manual' | 'pdf_import' | 'image_import';
  importFileName?: string;
  importStoragePath?: string;
  importConfidence?: number;
  importedAt?: string;
  ocrRawText?: string;
  createdAt: string;
  updatedAt: string;
  payments?: InvoicePayment[];
}

export interface InvoicePayment {
  id: string;
  invoiceId: string;
  userId: string;
  amount: number;
  paidAt: string;
  paymentMethod?: string;
  paymentReference?: string;
  notes?: string;
  createdAt: string;
}

export interface ExtractedInvoiceData {
  clientName: string;
  clientNif: string;
  amountBase: number;
  ivaRate: number;
  irpfRetention: number;
  totalAmount: number;
  issueDate: string;
  invoiceNumber?: string;
  series?: string;
  confidence: number;
  rawText: string;
  warnings: string[];
}

export interface UploadResult {
  fileName: string;
  originalName: string;
  filePath: string;
  importSource: 'pdf_import' | 'image_import';
  extractedData: ExtractedInvoiceData;
  invoice?: Invoice;
}

// Estados de factura con colores
export const INVOICE_STATUS_CONFIG = {
  draft: { label: 'Borrador', color: 'bg-gray-100 text-gray-800', icon: 'FileText' },
  issued: { label: 'Emitida', color: 'bg-blue-100 text-blue-800', icon: 'Send' },
  paid: { label: 'Pagada', color: 'bg-green-100 text-green-800', icon: 'CheckCircle' }
} as const;

// Origen de importación con iconos
export const IMPORT_SOURCE_CONFIG = {
  manual: { label: 'Manual', icon: 'Edit' },
  pdf_import: { label: 'PDF', icon: 'FileText' },
  image_import: { label: 'Imagen', icon: 'Image' }
} as const;
