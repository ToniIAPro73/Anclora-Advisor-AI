'use client';

import { 
  FileText, Image, Calendar, Euro, User, Hash, 
  Mail, FileCheck, AlertTriangle, Edit
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { Invoice } from './types';
import { INVOICE_STATUS_CONFIG, IMPORT_SOURCE_CONFIG } from './types';

interface InvoiceViewDialogProps {
  invoice: Invoice | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onEdit: (invoice: Invoice) => void;
}

export function InvoiceViewDialog({ invoice, open, onOpenChange, onEdit }: InvoiceViewDialogProps) {
  if (!invoice) return null;

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('es-ES', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: 'EUR'
    }).format(amount);
  };

  const getStatusConfig = () => {
    return INVOICE_STATUS_CONFIG[invoice.status as keyof typeof INVOICE_STATUS_CONFIG] || INVOICE_STATUS_CONFIG.draft;
  };

  const getSourceConfig = () => {
    return IMPORT_SOURCE_CONFIG[invoice.importSource as keyof typeof IMPORT_SOURCE_CONFIG] || IMPORT_SOURCE_CONFIG.manual;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-lg">
              <FileText className="h-5 w-5 text-primary" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                Factura {invoice.series && invoice.invoiceNumber ? `${invoice.series}-${String(invoice.invoiceNumber).padStart(3, '0')}` : ''}
              </div>
              <Badge 
                variant="outline" 
                className={`${getStatusConfig().color} border-0 mt-1`}
              >
                {getStatusConfig().label}
              </Badge>
            </div>
          </DialogTitle>
          <DialogDescription>
            Detalles de la factura importada
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="max-h-[60vh] pr-4">
          <div className="space-y-6 py-4">
            {/* Información de importación */}
            {invoice.importSource !== 'manual' && (
              <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                {invoice.importSource === 'pdf_import' ? (
                  <FileText className="h-5 w-5 text-red-500" />
                ) : (
                  <Image className="h-5 w-5 text-blue-500" />
                )}
                <div className="flex-1">
                  <p className="text-sm font-medium">{invoice.importFileName}</p>
                  <p className="text-xs text-muted-foreground">
                    Importado el {invoice.importedAt && formatDate(invoice.importedAt)}
                  </p>
                </div>
                {invoice.importConfidence && (
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">Confianza OCR</p>
                    <p className={`font-bold ${
                      invoice.importConfidence >= 80 ? 'text-green-600' :
                      invoice.importConfidence >= 50 ? 'text-amber-600' : 'text-red-600'
                    }`}>
                      {invoice.importConfidence}%
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Datos del cliente */}
            <div className="space-y-3">
              <h4 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <User className="h-4 w-4" />
                Datos del Cliente
              </h4>
              <div className="grid grid-cols-2 gap-4 p-4 bg-muted/30 rounded-lg">
                <div>
                  <p className="text-xs text-muted-foreground">Nombre / Razón Social</p>
                  <p className="font-medium">{invoice.clientName}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">NIF / CIF</p>
                  <p className="font-medium font-mono">{invoice.clientNif}</p>
                </div>
              </div>
            </div>

            <Separator />

            {/* Datos financieros */}
            <div className="space-y-3">
              <h4 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Euro className="h-4 w-4" />
                Datos Financieros
              </h4>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-muted/30 rounded-lg">
                  <p className="text-xs text-muted-foreground">Base Imponible</p>
                  <p className="text-xl font-bold">{formatCurrency(invoice.amountBase)}</p>
                </div>
                <div className="p-4 bg-muted/30 rounded-lg">
                  <p className="text-xs text-muted-foreground">IVA ({invoice.ivaRate}%)</p>
                  <p className="text-xl font-bold">
                    {formatCurrency(invoice.amountBase * invoice.ivaRate / 100)}
                  </p>
                </div>
                <div className="p-4 bg-muted/30 rounded-lg">
                  <p className="text-xs text-muted-foreground">IRPF ({invoice.irpfRetention}%)</p>
                  <p className="text-xl font-bold text-red-500">
                    -{formatCurrency(invoice.amountBase * invoice.irpfRetention / 100)}
                  </p>
                </div>
                <div className="p-4 bg-primary/10 rounded-lg border border-primary/20">
                  <p className="text-xs text-primary">Total</p>
                  <p className="text-2xl font-bold text-primary">
                    {formatCurrency(invoice.totalAmount)}
                  </p>
                </div>
              </div>
            </div>

            <Separator />

            {/* Datos de la factura */}
            <div className="space-y-3">
              <h4 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Hash className="h-4 w-4" />
                Datos de la Factura
              </h4>
              <div className="grid grid-cols-3 gap-4 p-4 bg-muted/30 rounded-lg">
                <div>
                  <p className="text-xs text-muted-foreground">Fecha Emisión</p>
                  <p className="font-medium">{formatDate(invoice.issueDate)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Serie</p>
                  <p className="font-medium">{invoice.series || '-'}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Número</p>
                  <p className="font-medium">{invoice.invoiceNumber || '-'}</p>
                </div>
              </div>

              {invoice.recipientEmail && (
                <div className="flex items-center gap-2 p-3 bg-muted/30 rounded-lg">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Email destinatario</p>
                    <p className="font-medium">{invoice.recipientEmail}</p>
                  </div>
                </div>
              )}

              {invoice.paymentNotes && (
                <div className="p-3 bg-muted/30 rounded-lg">
                  <p className="text-xs text-muted-foreground mb-1">Notas</p>
                  <p className="text-sm">{invoice.paymentNotes}</p>
                </div>
              )}
            </div>

            {/* Pagos */}
            {invoice.payments && invoice.payments.length > 0 && (
              <>
                <Separator />
                <div className="space-y-3">
                  <h4 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <FileCheck className="h-4 w-4" />
                    Pagos Registrados ({invoice.payments.length})
                  </h4>
                  <div className="space-y-2">
                    {invoice.payments.map((payment) => (
                      <div key={payment.id} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                        <div>
                          <p className="font-medium">{formatCurrency(payment.amount)}</p>
                          <p className="text-xs text-muted-foreground">
                            {formatDate(payment.paidAt)}
                            {payment.paymentMethod && ` · ${payment.paymentMethod}`}
                          </p>
                        </div>
                        {payment.notes && (
                          <p className="text-xs text-muted-foreground">{payment.notes}</p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}

            {/* Timestamps */}
            <Separator />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Creada: {formatDate(invoice.createdAt)}</span>
              <span>Actualizada: {formatDate(invoice.updatedAt)}</span>
            </div>
          </div>
        </ScrollArea>

        <div className="flex justify-end gap-2 pt-4 border-t">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cerrar
          </Button>
          <Button onClick={() => {
            onOpenChange(false);
            onEdit(invoice);
          }}>
            <Edit className="h-4 w-4 mr-2" />
            Editar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
